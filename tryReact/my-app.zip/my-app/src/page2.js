import React from "react"

function Page2(){
    return(
        <h2>Page2</h2>
    )
}

export default Page2